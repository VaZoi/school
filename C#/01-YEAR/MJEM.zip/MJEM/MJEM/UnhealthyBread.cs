﻿namespace MJEM;

internal class UnhealthyBread : Bread
{
    internal UnhealthyBread(string description) : base(description)
    {
        Price = 0.75M;
    }

}
