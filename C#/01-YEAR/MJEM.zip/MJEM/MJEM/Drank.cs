﻿namespace MJEM;

    internal class Drank
    {

    internal Drank(decimal Price)
    {
        Price = 0.75M;
    }

    internal Drank(int Points)
    {
        Points = 2;
    }
}

