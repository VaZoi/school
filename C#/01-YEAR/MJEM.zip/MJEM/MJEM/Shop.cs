﻿
namespace MJEM;

internal class Shop
{
    
    readonly Schap schap1 = new()
    {
        new HealthyBread("Volkoren"),
        new UnhealthyBread("Chocolate Bread"),
        new UnhealthyBread("Croissant"),
        new UnhealthyBread("Coffee Bread"),
        new HealthyBread("Cheese Bread"),
        new HealthyBread("Cheese Bread"),
    };
}
