﻿namespace MJEM;

internal class Bag : List<Bread>
{

}
