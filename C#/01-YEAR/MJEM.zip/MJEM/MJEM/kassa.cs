﻿namespace MJEM;

internal class kassa
{
    public static void Kassabon()
    {
      
    }
}
