﻿namespace MJEM;

internal class Schap : List<Bread>
{
   
}

