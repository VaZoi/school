﻿namespace MJEM;

internal class HealthyBread : Bread
{
    internal HealthyBread(string description) : base(description)
    {
        Price = 0.50M;
    }
}


