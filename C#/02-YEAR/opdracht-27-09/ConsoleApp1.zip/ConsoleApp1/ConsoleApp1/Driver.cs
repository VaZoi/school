﻿namespace ConsoleApp1
{
    internal class Driver : Human
    {
        public string? rijbewijsnummer
        {
            get; set;
        }
    }
}
