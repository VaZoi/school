﻿namespace ConsoleApp1
{
    internal class Human
    {
        public string? Naam
        { 
            get; set; 
        }

        public int leeftijd
        {
            get; set;
        }
    }
}
